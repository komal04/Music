package com.example.komalshahi.musicalapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class sad extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_list);
        ArrayList<song> songs = new ArrayList<song>();
        songs.add(new song("Maahiya Teri Kasam","Lata Mangeshkar,Pankaj Udhas",R.drawable.musicicon));
        songs.add(new song("Main Phir Bhi Tumko Chahunga","Arijit Singh",R.drawable.musicicon));
        songs.add(new song("Tu Jaane Na","Atif Aslam",R.drawable.musicicon));
        songs.add(new song("Tum Bin","Shreya Ghoshal",R.drawable.musicicon));
        songs.add(new song("Bin Tere","Sunidhi Chauhan",R.drawable.musicicon));
        songs.add(new song("Lo maan Liya humne","Arijit Singh",R.drawable.musicicon));
        songs.add(new song("Baatein Ye Kabhi Na","Arijit Singh",R.drawable.musicicon));
        songs.add(new song("Tujhe Bhula diya","Mohit Chauhan,Shekhar Ravjiani&Shruti Pathak",R.drawable.musicicon));
        songs.add(new song("Agar Tum Saath Ho","Arijit Singh, Alka Yagnik",R.drawable.musicicon));
        songs.add(new song("Teri Zarrorat Hai","Mustafa Zahid",R.drawable.musicicon));

        songAdapter Adapter = new songAdapter(this, songs);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(Adapter);

    }
}
