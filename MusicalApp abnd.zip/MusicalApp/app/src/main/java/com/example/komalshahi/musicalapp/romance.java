package com.example.komalshahi.musicalapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class romance extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_list);
        ArrayList<song> songs = new ArrayList<song>();
        songs.add(new song("O Saathi","Atif Aslam",R.drawable.musicicon));
        songs.add(new song("Dil Diyan Gallan","Atif aslam",R.drawable.musicicon));
        songs.add(new song("sanu Ek Pal Chain","Rahat Fateh Ali Khan",R.drawable.musicicon));
        songs.add(new song("Lo Safar","Jubin Nutiyal",R.drawable.musicicon));
        songs.add(new song("Ghar se Nikalte Hi","Armaan Mallik, Amaal Mallik",R.drawable.musicicon));
        songs.add(new song("Lae Dooba","Sunidhi Chauhan",R.drawable.musicicon));
        songs.add(new song("Bandeya","Sharib-Toshi,Arijit Singh",R.drawable.musicicon));
        songs.add(new song("Sapna","Arijit Singh",R.drawable.musicicon));
        songs.add(new song("Yaad Hai","Palak Muchhal,Ankit Tiwari",R.drawable.musicicon));
        songs.add(new song("Baarish","Ash King,Shashaa Tirupati",R.drawable.musicicon));

        songAdapter Adapter = new songAdapter(this, songs);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(Adapter);

    }
}
