package com.example.komalshahi.musicalapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class song{
    /**song name*/
    private String mSongName;
    /**artist name*/
    private String mArtistName;

    /**image*/
    private int mImageResourceId;

    public song(String songName, String artistName , int imageResourceId){
        mSongName = songName;
       mArtistName = artistName;
        mImageResourceId = imageResourceId;
    }

    public String getSongName() {return mSongName;}

    public String getArtistName(){return mArtistName;}

    public int getImageResourceId(){return mImageResourceId;}

}
