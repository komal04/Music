package com.example.komalshahi.musicalapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class party extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_list);
        ArrayList<song> songs = new ArrayList<song>();
        songs.add(new song("Cheap Thrills","Sia",R.drawable.musicicon));
        songs.add(new song("Heeriye","Meet Bros",R.drawable.musicicon));
        songs.add(new song("Tareefan","Badshah",R.drawable.musicicon));
        songs.add(new song("Bom Diggy Diggy","Zack Knight,Jasmin Walia",R.drawable.musicicon));
        songs.add(new song("Swag se Sawat","Vishal Dadlani,Neha Bhasin ",R.drawable.musicicon));
        songs.add(new song("Disco Disco","Benny Dayal,Shirley Setia",R.drawable.musicicon));
        songs.add(new song("Dil Chori Sadda","Yo Yo Honey Singh",R.drawable.musicicon));
        songs.add(new song("Buzz","Aastha Gill, Badshah",R.drawable.musicicon));
        songs.add(new song("Patola","Guru Randhawa",R.drawable.musicicon));
        songs.add(new song("Pallo Latke","jyotica Tangri, Yaseer Desai",R.drawable.musicicon));

        songAdapter Adapter = new songAdapter(this, songs);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(Adapter);

    }
}
