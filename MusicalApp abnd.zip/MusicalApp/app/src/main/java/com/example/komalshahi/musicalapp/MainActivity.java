package com.example.komalshahi.musicalapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find the View that shows the party category
        TextView party = (TextView) findViewById(R.id.partymusic);
        // Set a click listener on that View
        party.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link partyActivity}
                Intent partyIntent = new Intent(MainActivity.this, party.class);
                startActivity(partyIntent);

            }

    });


    // Find the View that shows the romantic category
            TextView romance = (TextView) findViewById(R.id.romancemusic);
            // Set a click listener on that View
                    romance.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            // create a new intent to open the romanticActivity
                            Intent romanticIntent = new Intent(MainActivity.this, romance.class);
                            startActivity(romanticIntent);
                        }

                    });


        // Find the View that shows the sad category
        TextView sad = (TextView) findViewById(R.id.sadmusic);
        // Set a click listener on that View
        sad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // create a new intent to open the sadActivity
                Intent sadIntent = new Intent(MainActivity.this, sad.class);
                startActivity(sadIntent);
            }

        });

        //Find the View that shows the now playing category
        TextView playing = (TextView) findViewById(R.id.nowplaying);
        //Set a click listener on that View
        playing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // create a new intent to open the nowplayingActivity
                Intent playingIntent = new Intent(MainActivity.this, nowplaying.class);
                startActivity(playingIntent);
            }
        });


        }
}
